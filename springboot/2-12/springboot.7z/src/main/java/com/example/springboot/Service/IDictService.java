package com.example.springboot.Service;

import com.example.springboot.entity.Dict;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lv
 * @since 2024-02-07
 */
public interface IDictService extends IService<Dict> {

}
