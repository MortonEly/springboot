package com.example.springboot.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.SysLog;

public interface ISysLogService extends IService<SysLog> {
}
